/* Combined JavaScript - Generated automatically */
/* DO NOT EDIT - Modify source files instead */

/* === common.js === */
/**
 *   GPStar Stream Effects - Ghostbusters Props, Mods, and Kits.
 *   Copyright (C) 2024-2026 Dustin Grau <dustin.grau@gmail.com>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, see <https://www.gnu.org/licenses/>.
 *
 */

/** Common JavaScript - Device Specific **/

/**
 * Appended shared JavaScript functions from SharedLib/WebAssets/*.js below:
 *  - api.js
 *  - dom.js
 *  - help.js
 *  - utils.js
 */

/* === api.js === */
/** Connection Overlay - Prevents interaction when device is disconnected */

function initConnectionOverlay() {
  // Create overlay element if it doesn't exist
  if (!document.getElementById('connectionOverlay')) {
    const overlay = document.createElement('div');
    overlay.id = 'connectionOverlay';
    overlay.className = 'connection-overlay';
    
    const content = document.createElement('div');
    content.className = 'connection-overlay-content';
    content.id = 'connectionOverlayContent';
    content.innerHTML = '<p>Reconnecting...</p>';
    
    overlay.appendChild(content);
    
    // Prevent any events from bubbling through
    overlay.addEventListener('click', (e) => e.stopPropagation(), true);
    overlay.addEventListener('touchstart', (e) => e.stopPropagation(), true);
    overlay.addEventListener('touchend', (e) => e.stopPropagation(), true);
    overlay.addEventListener('pointerdown', (e) => e.stopPropagation(), true);
    overlay.addEventListener('wheel', (e) => e.stopPropagation(), true);
    
    document.body.appendChild(overlay);
  }
}

function showConnectionOverlay(attemptNumber = null) {
  initConnectionOverlay();
  const overlay = document.getElementById('connectionOverlay');
  const content = document.getElementById('connectionOverlayContent');
  
  if (attemptNumber !== null) {
    content.innerHTML = `<p>Reconnecting...</p><p class="connection-overlay-attempt">Attempt ${attemptNumber}</p>`;
  } else {
    content.innerHTML = '<p>Reconnecting...</p>';
  }
  
  if (overlay) {
    overlay.classList.add('active');
  }
}

function hideConnectionOverlay() {
  const overlay = document.getElementById('connectionOverlay');
  if (overlay) {
    overlay.classList.remove('active');
  }
}

/** WebSocket Client - Handles WebSocket connections with exponential backoff and timeout */
class WebSocketClient {
  // Private fields
  #websocket = null;                      // WebSocket instance
  #isConnected = false;                   // True if WebSocket is open and ready
  #hasEverConnected = false;              // Track if connection ever succeeded (for overlay)
  #wsHeartbeatTimer = null;               // Periodic heartbeat send timer
  #heartbeatMissCount = 0;                // Count consecutive missed pongs (reconnect on 2nd)
  #wsConnectionAttempts = 0;              // Track attempts for exponential backoff
  #wsReconnectDelay = 1000;               // Initial delay before reconnect (ms)
  #wsReconnectDelayMax = 30000;           // Max reconnect delay cap (ms)
  #wsReconnectTimer = null;               // Timer for scheduled reconnection attempt
  #heartbeatIntervalConnected = 3000;     // Heartbeat frequency when connected (3s)
  #heartbeatIntervalDisconnected = 30000; // Heartbeat frequency when disconnected (30s)
  #heartbeatResponseTimer = null;         // Timer waiting for pong response
  #heartbeatResponseWaitTime = 2000;      // Time to wait for pong before miss (2s)
  
  /**
   * Initialize WebSocket client
   * @param {Object} config - Configuration object
   * @param {string} config.hostname - Device hostname (default: window.location.hostname)
   * @param {string} config.wsPath - WebSocket path (default: '/ws')
   * @param {number} config.connectionTimeout - Connection timeout in ms
   * @param {number} config.heartbeatIntervalConnected - Heartbeat interval when connected (ms)
   * @param {number} config.heartbeatIntervalDisconnected - Heartbeat interval when disconnected (ms)
   * @param {number} config.wsReconnectDelay - Initial reconnect delay in ms
   * @param {number} config.wsReconnectDelayMax - Max reconnect delay in ms
   * @param {number} config.heartbeatResponseWaitTime - Time to wait for heartbeat response in ms
   * @param {Function} config.onOpen - Called when connection opens
   * @param {Function} config.onClose - Called when connection closes
   * @param {Function} config.onError - Called when connection error occurs
   * @param {Function} config.onMessage - Called when message received (receives event)
   */
  constructor(config = {}) {
    this.hostname = config.hostname || window.location.hostname;
    this.wsPath = config.wsPath || '/ws';
    this.onOpen = config.onOpen || (() => {});
    this.onClose = config.onClose || (() => {});
    this.onError = config.onError || (() => {});
    this.onMessage = config.onMessage || (() => {});
    this.connectionTimeout = config.connectionTimeout || 5000;
    
    // Private field initialization with optional config overrides
    this.#wsReconnectDelay = config.wsReconnectDelay || 1000;
    this.#wsReconnectDelayMax = config.wsReconnectDelayMax || 30000;
    this.#heartbeatIntervalConnected = config.heartbeatIntervalConnected || 3000;
    this.#heartbeatIntervalDisconnected = config.heartbeatIntervalDisconnected || 30000;
    this.#heartbeatResponseWaitTime = config.heartbeatResponseWaitTime || 2000;
  }
  
  /**
   * Get current connection state
   * @returns {boolean} True if WebSocket is connected
   */
  get isConnected() {
    return this.#isConnected;
  }
  
  /**
   * Connect to WebSocket with automatic backoff on failure
   */
  connect() {
    // Clear any pending reconnection attempt
    if (this.#wsReconnectTimer) {
      clearTimeout(this.#wsReconnectTimer);
    }
    
    console.log("WebSocket: Attempting connection... (attempt " + (this.#wsConnectionAttempts + 1) + ")");
    const gateway = "ws://" + this.hostname + this.wsPath;
    
    try {
      this.#websocket = new WebSocket(gateway);
      this.#websocket.onopen = (e) => this._handleOpen(e);
      this.#websocket.onclose = (e) => this._handleClose(e);
      this.#websocket.onerror = (e) => this._handleError(e);
      this.#websocket.onmessage = (e) => this._handleMessage(e);
      
      this.#wsConnectionAttempts++;
      
      // Timeout connection attempt after configured duration
      this.#wsReconnectTimer = setTimeout(() => {
        if (this.#websocket && this.#websocket.readyState === WebSocket.CONNECTING) {
          console.log("WebSocket: Connection timeout - closing attempt");
          this.#websocket.close();
        }
      }, this.connectionTimeout);
    } catch (error) {
      console.error("WebSocket: Failed to create:", error);
      this._scheduleReconnect();
    }
  }
  
  /**
   * Send message over WebSocket if connected
   * @param {any} data - Data to send
   * @returns {boolean} True if message was queued
   */
  send(data) {
    if (this.#websocket && this.#websocket.readyState === WebSocket.OPEN) {
      this.#websocket.send(data);
      return true;
    }
    return false;
  }
  
  /**
   * Disconnect WebSocket
   */
  disconnect() {
    if (this.#websocket) {
      this.#websocket.close();
      this.#websocket = null;
    }
    if (this.#wsReconnectTimer) {
      clearTimeout(this.#wsReconnectTimer);
      this.#wsReconnectTimer = null;
    }
    if (this.#wsHeartbeatTimer) {
      clearTimeout(this.#wsHeartbeatTimer);
      this.#wsHeartbeatTimer = null;
    }
    if (this.#heartbeatResponseTimer) {
      clearTimeout(this.#heartbeatResponseTimer);
      this.#heartbeatResponseTimer = null;
    }
  }
  
  /**
   * Internal: Handle connection open
   */
  _handleOpen(event) {
    console.log("WebSocket: Connection opened");
    if (this.#wsReconnectTimer) {
      clearTimeout(this.#wsReconnectTimer);
      this.#wsReconnectTimer = null;
    }
    this.#isConnected = true;
    this.#hasEverConnected = true;
    this.#wsConnectionAttempts = 0;
    this.#wsReconnectDelay = 1000;
    this.#heartbeatMissCount = 0;
    hideConnectionOverlay();
    this._startHeartbeat();
    this.onOpen(event);
  }
  
  /**
   * Internal: Handle connection close
   */
  _handleClose(event) {
    console.log("WebSocket: Connection closed");
    this.#isConnected = false;
    if (this.#wsReconnectTimer) {
      clearTimeout(this.#wsReconnectTimer);
    }
    if (this.#hasEverConnected) {
      showConnectionOverlay(this.#wsConnectionAttempts + 1);
    }
    this._scheduleReconnect();
    this.onClose(event);
  }
  
  /**
   * Internal: Handle connection error
   */
  _handleError(event) {
    console.error("WebSocket: Error:", event);
    this.onError(event);
  }
  
  /**
   * Internal: Handle incoming message
   */
  _handleMessage(event) {
    // Clear heartbeat response timer if we receive a pong
    if (event.data === "pong") {
      if (this.#heartbeatResponseTimer) {
        clearTimeout(this.#heartbeatResponseTimer);
        this.#heartbeatResponseTimer = null;
      }
      this.#heartbeatMissCount = 0; // Reset miss counter on successful pong
      //console.log("WebSocket: Heartbeat acknowledged");
      return; // Don't pass pong to application handlers
    }
    this.onMessage(event);
  }
  
  /**
   * Internal: Schedule reconnection with exponential backoff
   */
  _scheduleReconnect() {
    if (this.#wsReconnectTimer) {
      clearTimeout(this.#wsReconnectTimer);
    }
    
    const delayMs = Math.min(
      this.#wsReconnectDelay * Math.pow(1.5, Math.min(this.#wsConnectionAttempts, 5)),
      this.#wsReconnectDelayMax
    );
    const jitter = Math.random() * 1000;
    const totalDelay = Math.floor(delayMs + jitter);
    
    console.log("WebSocket: Reconnect scheduled in " + totalDelay + "ms (attempt " + (this.#wsConnectionAttempts + 1) + ")");
    this.#wsReconnectTimer = setTimeout(() => this.connect(), totalDelay);
  }
  
  /**
   * Internal: Start heartbeat timers (called on connection open)
   * Starts WebSocket heartbeat to keep connection alive
   */
  _startHeartbeat() {
    if (this.#wsHeartbeatTimer) {
      clearTimeout(this.#wsHeartbeatTimer);
    }
    this._doWsHeartbeat();
  }
  
  /**
   * Internal: Send periodic WebSocket heartbeat to keep connection alive
   */
  _doWsHeartbeat() {
    if (this.send("heartbeat")) {
      // Heartbeat sent successfully, start timer waiting for response
      if (this.#heartbeatResponseTimer) {
        clearTimeout(this.#heartbeatResponseTimer);
      }
      this.#heartbeatResponseTimer = setTimeout(() => this._checkHeartbeatResponse(), this.#heartbeatResponseWaitTime);
    }
    const interval = this.#isConnected ? this.#heartbeatIntervalConnected : this.#heartbeatIntervalDisconnected;
    this.#wsHeartbeatTimer = setTimeout(() => this._doWsHeartbeat(), interval);
  }
  
  /**
   * Internal: Check if heartbeat response was received (called on timeout)
   * Increments miss counter; closes connection and reconnects on 2nd miss
   */
  _checkHeartbeatResponse() {
    this.#heartbeatMissCount++;
    console.log("WebSocket: Heartbeat response timeout (miss #" + this.#heartbeatMissCount + ")");
    
    if (this.#heartbeatMissCount >= 2) {
      console.log("WebSocket: 2nd heartbeat miss - closing connection and reconnecting");
      this.#heartbeatResponseTimer = null;
      if (this.#websocket) {
        this.#websocket.close();
      }
    } else {
      this.#heartbeatResponseTimer = null;
    }
  }
}

/** EventSource Manager - Handles Server-Sent Events with flexible event handlers **/
class EventSourceManager {
  // Private fields
  #eventSource = null;
  
  /**
   * Initialize EventSource manager
   * @param {Object} config - Configuration object
   * @param {Object} config.eventHandlers - Map of event names to handler functions
   *                                        e.g., { 'debug': (data) => {...}, 'telemetry': (data) => {...} }
   */
  constructor(config = {}) {
    this.eventHandlers = config.eventHandlers || {};
  }
  
  /**
   * Connect to EventSource and register event handlers
   */
  connect() {
    if (!window.EventSource) {
      console.warn("EventSource: Not supported in this browser");
      return;
    }
    
    console.log("EventSource: Connecting...");
    this.#eventSource = new EventSource("/events");
    
    // Standard open handler
    this.#eventSource.addEventListener("open", () => {
      console.log("EventSource: Connected");
    }, false);
    
    // Standard error handler
    this.#eventSource.addEventListener("error", (e) => {
      if (e.target.readyState !== EventSource.OPEN) {
        console.log("EventSource: Disconnected");
      }
    }, false);
    
    // Register custom event handlers
    Object.keys(this.eventHandlers).forEach((eventName) => {
      this.#eventSource.addEventListener(eventName, (e) => {
        try {
          const data = e.data;
          if (data && data !== "") {
            // Attempt to parse as JSON, fall back to raw string if it fails
            let parsedData = data;
            try {
              parsedData = JSON.parse(data);
            } catch (parseError) {
              // If JSON parsing fails, use raw string data
              console.debug("EventSource: Handler '" + eventName + "' received non-JSON data");
            }
            this.eventHandlers[eventName](parsedData);
          } else {
            console.debug("EventSource: Event '" + eventName + "' received without data");
          }
        } catch (error) {
          console.error("EventSource: Handler error for '" + eventName + "':", error);
        }
      }, false);
    });
  }
  
  /**
   * Register an event handler dynamically
   * @param {string} eventName - Name of the event
   * @param {Function} handler - Handler function
   */
  on(eventName, handler) {
    if (!this.#eventSource) {
      console.warn("EventSource: Not connected, caching handler for '" + eventName + "'");
    }
    this.eventHandlers[eventName] = handler;
    if (this.#eventSource) {
      this.#eventSource.addEventListener(eventName, (e) => {
        try {
          const data = e.data;
          if (data && data !== "") {
            // Attempt to parse as JSON, fall back to raw string if it fails
            let parsedData = data;
            try {
              parsedData = JSON.parse(data);
            } catch (parseError) {
              // If JSON parsing fails, use raw string data
              console.debug("EventSource: Handler '" + eventName + "' received non-JSON data");
            }
            handler(parsedData);
          } else {
            console.debug("EventSource: Event '" + eventName + "' received without data");
          }
        } catch (error) {
          console.error("EventSource: Handler error for '" + eventName + "':", error);
        }
      }, false);
    }
  }
  
  /**
   * Close EventSource connection
   */
  disconnect() {
    if (this.#eventSource) {
      this.#eventSource.close();
      this.#eventSource = null;
    }
  }
}

/** XHR Helper - Consistent request handling with timeout and error management **/
class XHRHelper {
  /**
   * Initialize XHR helper
   * @param {Object} config - Configuration object
   * @param {number} config.timeout - Request timeout in ms (default: 5000)
   * @param {Function} config.onError - Called on network error
   */
  constructor(config = {}) {
    this.timeout = config.timeout || 5000;
    this.onError = config.onError || (() => {});
  }
  
  /**
   * Send GET request
   * @param {string} url - URL to request
   * @param {Function} callback - Called with parsed JSON response
   */
  get(url, callback) {
    var xhttp = new XMLHttpRequest();
    xhttp.timeout = this.timeout;
    xhttp.onreadystatechange = () => {
      if (xhttp.readyState == 4) {
        if (xhttp.status >= 200 && xhttp.status < 300) {
          if (callback && typeof callback === "function") {
            try {
              callback(JSON.parse(xhttp.responseText));
            } catch (e) {
              console.error("XHR: JSON parse error:", e);
            }
          }
        } else {
          console.warn("XHR: GET " + url + " failed with status " + xhttp.status);
          this.onError(xhttp);
        }
      }
    };
    xhttp.onerror = () => {
      console.error("XHR: GET " + url + " network error");
      this.onError(xhttp);
    };
    xhttp.open("GET", url, true);
    xhttp.send();
    return true;
  }
  
  /**
   * Send PUT request
   * @param {string} url - URL to request
   * @param {any} data - Data to send (optional)
   * @param {Function} callback - Called with response (optional)
   */
  put(url, data, callback) {
    var xhttp = new XMLHttpRequest();
    xhttp.timeout = this.timeout;
    xhttp.onreadystatechange = () => {
      if (xhttp.readyState == 4) {
        if (callback && typeof callback === "function") {
          callback(xhttp.responseText);
        }
        if (!(xhttp.status >= 200 && xhttp.status < 300)) {
          console.warn("XHR: PUT " + url + " failed with status " + xhttp.status);
          this.onError(xhttp);
        }
      }
    };
    xhttp.onerror = () => {
      console.error("XHR: PUT " + url + " network error");
      this.onError(xhttp);
    };
    xhttp.open("PUT", url, true);
    xhttp.send(data || null);
    return true;
  }
  
  /**
   * Send POST request
   * @param {string} url - URL to request
   * @param {any} data - Data to send
   * @param {Function} callback - Called with response (optional)
   */
  post(url, data, callback) {
    var xhttp = new XMLHttpRequest();
    xhttp.timeout = this.timeout;
    xhttp.onreadystatechange = () => {
      if (xhttp.readyState == 4) {
        if (callback && typeof callback === "function") {
          callback(xhttp.responseText);
        }
        if (!(xhttp.status >= 200 && xhttp.status < 300)) {
          console.warn("XHR: POST " + url + " failed with status " + xhttp.status);
          this.onError(xhttp);
        }
      }
    };
    xhttp.onerror = () => {
      console.error("XHR: POST " + url + " network error");
      this.onError(xhttp);
    };
    xhttp.open("POST", url, true);
    xhttp.send(data || null);
    return true;
  }
  
  /**
   * Send DELETE request
   * @param {string} url - URL to request
   * @param {Function} callback - Called with response (optional)
   */
  delete(url, callback) {
    var xhttp = new XMLHttpRequest();
    xhttp.timeout = this.timeout;
    xhttp.onreadystatechange = () => {
      if (xhttp.readyState == 4) {
        if (callback && typeof callback === "function") {
          callback(xhttp.responseText);
        }
        if (!(xhttp.status >= 200 && xhttp.status < 300)) {
          console.warn("XHR: DELETE " + url + " failed with status " + xhttp.status);
          this.onError(xhttp);
        }
      }
    };
    xhttp.onerror = () => {
      console.error("XHR: DELETE " + url + " network error");
      this.onError(xhttp);
    };
    xhttp.open("DELETE", url, true);
    xhttp.send();
    return true;
  }
}

/** Global XHR Helper - Available to all projects for consistent request handling **/
const xhrHelper = new XHRHelper();

/** General API Callbacks - Common functions for data responses **/

function updateNetworkInfo(jObj) {
  if (jObj) {
    // Display local AP network name
    if (jObj.localAP && jObj.localAP.ssid) {
      setHtml("wifiName", "Private Network: " + jObj.localAP.ssid);
    }

    // Display client counts
    var clientText = "AP Clients: " + (jObj.apClients ?? 0) + " / WebSocket Clients: " + (jObj.wsClients ?? 0);
    setHtml("clientInfo", clientText);

    // Display external WiFi info if connected
    if (jObj.extWifi && jObj.extWifi.enabled && jObj.extWifi.connected) {
      var extInfo = jObj.extWifi.ssid + ": " + jObj.extWifi.address + " / " + jObj.extWifi.subnet;
      setHtml("extWifi", extInfo);
    } else {
      setHtml("extWifi", ""); // Clear if not connected
    }
  }
}

/** General API Helpers - Common functions for device control **/

function sendCommand(apiUri) {
  // Sends an action command to the server (device) using a PUT request.
  // These commands have no response data, so we just handle the status.
  xhrHelper.put(apiUri, null, (response) => {
    handleStatus(response);
  });
}

function volSysUp() {
  sendCommand("/volume/master/up");
}

function volSysDown() {
  sendCommand("/volume/master/down");
}

function volFxUp() {
  sendCommand("/volume/effects/up");
}

function volFxDown() {
  sendCommand("/volume/effects/down");
}

function volMusicUp() {
  sendCommand("/volume/music/up");
}

function volMusicDown() {
  sendCommand("/volume/music/down");
}

function musicStartStop() {
  sendCommand("/music/startstop");
}

function musicPauseResume() {
  sendCommand("/music/pauseresume");
}

function musicSelect(caller) {
  // Change the music track by selected option: /music/select?track=<#>
  sendCommand("/music/select?track=" + caller.value);
}

function musicPrev() {
  sendCommand("/music/prev");
}

function musicNext() {
  sendCommand("/music/next");
}

function toggleMute(el) {
  handleToggle(el, "/volume/mute", "/volume/unmute");
}

function musicLoop(el) {
  handleToggle(el, "/music/loop/one", "/music/loop/all");
}

function musicShuffle(el) {
  handleToggle(el, "/music/shuffle/on", "/music/shuffle/off");
}

function handleToggle(el, apiOn, apiOff) {
  if (el._lockout) return;
  el._lockout = true;

  const switchEl = el.parentElement.querySelector(".switch");

  function onTransitionEnd(e) {
    if (e.propertyName === "right") {
      sendCommand(el.checked ? apiOn : apiOff);
      el._lockout = false;
      switchEl.removeEventListener("transitionend", onTransitionEnd);
    }
  }

  switchEl.addEventListener("transitionend", onTransitionEnd);
}

function getStatus(callbackFunc) {
  // This function expects a JSON response from the server which must be parsed and sent to the callback function.
  xhrHelper.get("/status", (data) => {
    if (callbackFunc && typeof callbackFunc === "function") {
      callbackFunc(data);
    } else {
      console.warn("No callback function provided for getStatus response.");
    }
  });
}

function getNetworkInfo() {
  // Fetch network configuration and statistics from dedicated endpoint.
  xhrHelper.get("/wifi/status", updateNetworkInfo);
}

function doRestart() {
  // A special command which requires user confirmation before proceeding.
  if (confirm("Are you sure you wish to restart the serial device?")) {
    xhrHelper.delete("/restart", (response) => {
      // Reload the page after 2 seconds.
      setTimeout(function () {
        window.location.reload();
      }, 2000);
    });
  }
}

/* === dom.js === */
/** DOM Manipulation Utilities - Device-agnostic helpers for element access and manipulation **/

function getEl(id) {
  return document.getElementById(id);
}

function getInt(id) {
  return parseInt(getValue(id) ?? 0, 10);
}

function getFloat(id) {
  return parseFloat(getValue(id) ?? 0);
}

function getText(id) {
  return (getValue(id) || "").trim();
}

function getHtml(id) {
  return (getEl(id).innerHTML);
}

function getToggle(id) {
  var el = getEl(id);
  return el && el.checked ? true : false;
}

function getValue(id) {
  var el = getEl(id);
  return el && typeof el.value !== "undefined" ? el.value : null;
}

function setHtml(id, value) {
  var el = getEl(id);
  if (el) el.innerHTML = value || "";
}

function setToggle(id, value) {
  var el = getEl(id);
  if (el) {
    if (el._lockout != true) el.checked = value === true;
  }
}

function setValue(id, value) {
  var el = getEl(id);
  if (el) el.value = value;
}

function hideEl(id) {
  var el = getEl(id);
  if (el) el.style.display = "none";
}

function showEl(id) {
  var el = getEl(id);
  if (el) el.style.display = "block";
}

function disableEl(id) {
  var el = getEl(id);
  if (el) el.disabled = true;
}

function enableEl(id) {
  var el = getEl(id);
  if (el) el.disabled = false;
}

function colorEl(id, red, green, blue, alpha = 0.5) {
  var el = getEl(id);
  if (el) el.style.backgroundColor = "rgba(" + red + ", " + green + ", " + blue + ", " + alpha + ")";
}

function blinkEl(id, state) {
  var el = getEl(id);
  if (el) {
    if (state) {
      el.classList.add("blinking");
    } else {
      el.classList.remove("blinking");
    }
  }
}

function disableControls() {
  // Disables all form controls (inputs, selects, buttons)
  var controls = document.querySelectorAll('input, select, button');
  for (var i = 0; i < controls.length; i++) {
    controls[i].disabled = true;
  }
}

/* === help.js === */
/** Contextual Help System - Relies on a local help.json file **/

var helpData = null; // Cached help data from /help.json

function loadHelpData(callback) {
  // Fetch and cache the help.json file
  if (helpData !== null) {
    if (callback) callback();
    return;
  }

  xhrHelper.get("/help.json", function(data) {
    helpData = data;
    if (callback) callback();
  });
}

function showHelpModal(title, text) {
  // Create or show the help modal with the provided text
  var modal = getEl("helpModal");
  if (!modal) {
    // Create modal structure
    modal = document.createElement("div");
    modal.id = "helpModal";
    modal.className = "help-modal";
    modal.innerHTML =
      '<div class="help-modal-content">' +
      '<span class="help-modal-close">&times;</span>' +
      '<h3 id="helpModalTitle"></h3>' +
      '<p id="helpModalText"></p>' +
      "</div>";
    document.body.appendChild(modal);

    // Close button handler
    modal.querySelector(".help-modal-close").onclick = function () {
      modal.style.display = "none";
    };

    // Click outside to close
    modal.onclick = function (event) {
      if (event.target === modal) {
        modal.style.display = "none";
      }
    };
  }

  // Set content and show
  getEl("helpModalTitle").textContent = title || "Help";
  getEl("helpModalText").textContent = text || "No help available.";
  modal.style.display = "block";
}

function createHelpIcon(labelText, helpText) {
  // Create an info icon that shows help when clicked
  var icon = document.createElement("span");
  icon.className = "help-icon";
  icon.innerHTML = "&#9432;"; // Unicode info symbol (i in circle)
  icon.title = "Click for help";
  icon.onclick = function (e) {
    e.preventDefault();
    e.stopPropagation();
    showHelpModal(labelText, helpText);
  };
  return icon;
}

function initializeHelp(section) {
  // Initialize help icons for all fields in the specified section
  loadHelpData(function () {
    if (!helpData || !helpData[section]) {
      return;
    }

    var sectionHelp = helpData[section];
    for (var fieldId in sectionHelp) {
      if (sectionHelp.hasOwnProperty(fieldId)) {
        var element = getEl(fieldId);
        if (element) {
          var helpText = sectionHelp[fieldId];

          // Skip if helpText is null or empty (no help available)
          if (!helpText) {
            continue;
          }

          // Find the parent setting div or label to insert the icon
          var parent = element.closest(".setting");
          if (parent) {
            // Find the label text
            var label = parent.querySelector("b, .label");
            var labelText = fieldId; // Fallback to field ID

            if (label) {
              // Extract and clean the label text
              labelText = label.textContent || label.innerText || fieldId;
              labelText = labelText.trim().replace(/:$/, ""); // Remove trailing colon

              // Create and add the help icon
              var helpIcon = createHelpIcon(labelText, helpText);
              label.appendChild(document.createTextNode(" "));
              label.appendChild(helpIcon);
            } else {
              // For toggle switches, find the label span
              var toggleLabel = parent.querySelector("label .label");
              if (toggleLabel) {
                labelText = toggleLabel.textContent || toggleLabel.innerText || fieldId;
                labelText = labelText.trim().replace(/:$/, "");

                var helpIcon = createHelpIcon(labelText, helpText);
                toggleLabel.appendChild(document.createTextNode(" "));
                toggleLabel.appendChild(helpIcon);
              }
            }
          }
        }
      }
    }
  });
}

/* === utils.js === */
/** General Utility Functions - Device-agnostic helper functions **/

function isJsonString(str) {
  try {
    JSON.parse(str);
  } catch (e) {
    return false;
  }
  return true;
}

function handleStatus(response) {
  // Generic handler for a JSON response with a "status" field.
  // If a response is not JSON then the full text is displayed.
  if (isJsonString(response || "")) {
    var jObj = JSON.parse(response || "");
    if (jObj.status && jObj.status != "success") {
      alert(jObj.status); // Report non-success status.
    }
  } else {
    alert(response); // Display plain text message.
  }
}

function openTab(evt, tabName) {
  // Hide all tab contents
  var tabs = document.getElementsByClassName("tab");
  for (var i = 0; i < tabs.length; i++) {
    tabs[i].style.display = "none";
  }

  // Remove the active class from all tab links
  var tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  // Show the current tab and add an "active" class to the button that opened the tab
  showEl(tabName);
  evt.currentTarget.className += " active";
}

function getStreamColor(cMode, iTheme, iCustomVal = 200, iCustomSat = 254) {
  var color = [0, 0, 0];

  // Use this to do our colour-change for spectral streams.
  var tickSeconds = new Date().getSeconds();

  switch (cMode) {
    case "Plasm System":
      if (iTheme == 3) {
        // Pink
        color[0] = 200;
        color[2] = 180;
      } else {
        // Dark Green
        color[1] = 80;
      }
      break;
    case "Dark Matter Gen.":
      // Light Blue
      color[1] = 60;
      color[2] = 255;
      break;
    case "Particle System":
      // Orange
      color[0] = 255;
      color[1] = 140;
      break;
    case "Settings":
      // Gray
      color[0] = 40;
      color[1] = 40;
      color[2] = 40;
      break;
    case "Halloween":
      if (tickSeconds % 2) {
        // Orange
        color[0] = 255;
        color[1] = 140;
      } else {
        // Purple
        color[0] = 200;
        color[2] = 240;
      }
      break;
    case "Christmas":
      if (tickSeconds % 2) {
        // Red
        color[0] = 180;
      } else {
        // Green
        color[1] = 180;
      }
      break;
    case "Spectral Stream":
      switch (tickSeconds % 8) {
        case 0:
        default:
          // Red
          color[0] = 180;
          break;
        case 1:
          // Orange
          color[0] = 255;
          color[1] = 140;
          break;
        case 2:
          // Yellow
          color[0] = 240;
          color[1] = 220;
          break;
        case 3:
          // Green
          color[1] = 180;
          break;
        case 4:
          // Light Blue
          color[1] = 60;
          color[2] = 255;
          break;
        case 5:
          // Blue
          color[2] = 180;
          break;
        case 6:
          // Indigo
          color[0] = 90;
          color[2] = 240;
          break;
        case 7:
          // Purple
          color[0] = 200;
          color[2] = 240;
          break;
      }
      break;
    case "Custom Stream":
    default:
      // Proton Stream(s) as Red
      color[0] = 180;
      break;
  }

  return color;
}

